#include <bits/stdc++.h>
#define int long long
using namespace std;
int u,n,Start,End;
bool Flag[1005];
struct node2
{
	char kinds,names[25];
	int Max,Min,After_Print;
}Un_Groups[1005];
struct node
{
	node2 members[1005];
	int n;
	char Times[105];
}Groups[1005];
signed main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		printf("Groups?1.Yes 2.No: ");
		cin>>u;
		if(u==1)
		{
			Flag[i]=true;
			printf("members: ");
			cin>>Groups[i].n;
			for(int j=1;j<=Groups[i].n;j++)
			{
				cout<<"names: ";
				cin>>Groups[i].members[j].names;
				printf("kinds  d :");
				cin>>Groups[i].members[j].kinds;
				if(Groups[i].members[j].kinds=='d')
				{
					cout<<"Max: ";
					cin>>Groups[i].members[j].Max;
					cout<<"Min :";
					cin>>Groups[i].members[j].Min;
				}
				cout<<"After Print? -1 Don't Print this number 0.noting 1.' ' 2.'"<<(char)(92)<<"n': ";
				cin>>Groups[i].members[j].After_Print;
			}
			cout<<"Times: ";
			cin>>Groups[i].Times;
		}
		else
		{
			Flag[i]=false;
			cout<<"names: ";
			cin>>Un_Groups[i].names;
			printf("kinds  d :");
			cin>>Un_Groups[i].kinds;
			if(Un_Groups[i].kinds=='d')
			{
				cout<<"Max: ";
				cin>>Un_Groups[i].Max;
				cout<<"Min: ";
				cin>>Un_Groups[i].Min;
			}
			cout<<"After Print? -1 Don't Print this number 0.noting 1.' ' 2.'"<<(char)(92)<<"n': ";
			cin>>Un_Groups[i].After_Print;
		}
	}
	cout<<"Start: ";
	cin>>Start;
	cout<<"End: ";
	cin>>End;
	freopen("program.cpp","w",stdout);
	cout<<"#include <bits/stdc++.h>"<<endl;
	cout<<"using namespace std;"<<endl;
	for(int i=1;i<=n;i++)
	{
		if(Flag[i]==true)
		{
			for(int j=1;j<=Groups[i].n;j++)
			{
				if(Groups[i].members[j].kinds=='d')
				printf("long long %s;\n",Groups[i].members[j].names);
			}
		}
		else
		{
			if(Un_Groups[i].kinds=='d')
			printf("long long %s;\n",Un_Groups[i].names);
		}
	}
	printf("int main()\n");
	printf("{\n");
	printf("        srand(time(0));\n");
	for(int L=Start;L<=End;L++)
	{
		printf("        FILE * fout%lld;\n",L);
		printf("        fout%d=fopen(",L);cout<<'"'<<L<<".in"<<'"'<<','<<'"'<<"w+"<<'"'<<");"<<endl;
		for(int j=1;j<=n;j++)
		{
			if(Flag[j])
			{	
				printf("        for(int i=1;i<=%s;i++)\n",Groups[j].Times);
				printf("        {\n");
				for(int k=1;k<=Groups[j].n;k++)
				{
					if(Groups[j].members[k].After_Print==-1)
					continue;
					
					
					
					printf("                %s=((long long)(rand())*(long long)(rand())*(long long)(rand())*(long long)(rand()))%(%lld)+%lld;\n",Groups[j].members[k].names,Groups[j].members[k].Max-Groups[j].members[k].Min+1,Groups[j].members[k].Min);
					printf("                fprintf(fout%lld,",L);cout<<'"';cout<<"%";
					if(Groups[j].members[k].kinds=='d')
					printf("ll");
					printf("%c",Groups[j].members[k].kinds);
					
					if(Groups[j].members[k].After_Print==1)
					printf(" ");
					if(Groups[j].members[k].After_Print==2)
					cout<<(char)(92)<<'n';
					
					cout<<'"';printf(",%s);\n",Groups[j].members[k].names);
				}
				printf("        }\n");
			}
			else
			{
				if(Un_Groups[j].After_Print==-1)
				continue;
				
				printf("        %s=((long long)(rand())*(long long)(rand())*(long long)(rand())*(long long)(rand()))%(%lld)+%lld;\n",Un_Groups[j].names,Un_Groups[j].Max-Un_Groups[j].Min+1,Un_Groups[j].Min);
				printf("        fprintf(fout%lld,",L);cout<<'"';cout<<"%";
				if(Un_Groups[j].kinds=='d')
				printf("ll");
				printf("%c",Un_Groups[j].kinds);
				if(Un_Groups[j].After_Print==1)
				printf(" ");
				if(Un_Groups[j].After_Print==2)
				cout<<(char)(92)<<'n';
				
				cout<<'"';printf(",%s);\n",Un_Groups[j].names);
			}
		}
	}
	cout<<"        return 0;\n";
	cout<<"}";
}
